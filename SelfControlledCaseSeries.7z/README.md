SelfControlledCaseSeries
========================

MSCCS R package. Work in progress. Do not use.

# Acknowledgements
- This project is supported in part through the National Science Foundation grant IIS 1251151.
