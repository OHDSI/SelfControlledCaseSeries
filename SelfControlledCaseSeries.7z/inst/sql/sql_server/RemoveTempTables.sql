TRUNCATE TABLE #cases;
DROP TABLE #cases;

TRUNCATE TABLE #eras;
DROP TABLE #eras;

TRUNCATE TABLE #covariate_ref;
DROP TABLE #covariate_ref;
