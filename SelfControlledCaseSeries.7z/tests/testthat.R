library(testthat)
test_check("SelfControlledCaseSeries")
